package org.academiadecodigo.rhashtafaris.projectninja;

public class TrapBall extends Balls{

    public TrapBall(SimpleGfxPosition pos) {
        super(pos);
        this.setSpeed(BallType.TRAPBALL);
    }

}
