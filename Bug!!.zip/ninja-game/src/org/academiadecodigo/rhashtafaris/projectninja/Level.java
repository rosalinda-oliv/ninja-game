package org.academiadecodigo.rhashtafaris.projectninja;

import org.academiadecodigo.simplegraphics.pictures.Picture;

public class Level {

    private Picture backGround;
    private Picture foreGround;

    public Level() {
    }

}
